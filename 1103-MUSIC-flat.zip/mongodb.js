const { MongoClient } = require('mongodb');
const colors = require('./UI/colors/colors');
const config = require("./config.js");
require('dotenv').config();

let client; 

// Use MongoDB only if a real URI is set (placeholders like <cluster> are ignored).
const useMongo = !!config.mongodbUri && !/[<>]/.test(config.mongodbUri) && /^mongodb(\+srv)?:\/\//.test(config.mongodbUri);

if (useMongo) {
    const uri = config.mongodbUri;
    client = new MongoClient(uri);
} else {
    console.log("\x1b[36m[ DATABASE ]\x1b[0m No valid MONGODB_URI set - using the built-in local JSON database.");
}

async function connectToDatabase() {
    if (!useMongo) {
        console.log('\x1b[36m[ DATABASE ]\x1b[0m', '\x1b[32mUsing local JSON database (data/db) ✅\x1b[0m');
        return;
    }
    try {
        const { getLangSync } = require('./utils/languageLoader.js');
        const lang = getLangSync();
        if (!client) {
            console.warn("\x1b[33m[ WARNING ]\x1b[0m " + (lang.console?.mongodb?.skippingConnection || "Skipping MongoDB connection as URI is not provided."));
            return;
        }

        try {
            await client.connect();
            console.log('\n' + '─'.repeat(40));
            console.log(`${colors.magenta}${colors.bright}${lang.console?.bot?.databaseConnection || '🕸️  DATABASE CONNECTION'}${colors.reset}`);
            console.log('─'.repeat(40));
            console.log('\x1b[36m[ DATABASE ]\x1b[0m', '\x1b[32m' + (lang.console?.mongodb?.connected || 'Connected to MongoDB ✅') + '\x1b[0m');
        } catch (err) {
            console.warn("\x1b[33m[ WARNING ]\x1b[0m " + (lang.console?.mongodb?.connectionFailed || "Could not connect to MongoDB. Continuing without database functionality."));
            console.error(err.message);
        }
    } catch (e) {
        if (!client) {
            console.warn("\x1b[33m[ WARNING ]\x1b[0m Skipping MongoDB connection as URI is not provided.");
            return;
        }
        try {
            await client.connect();
            console.log('\n' + '─'.repeat(40));
            console.log(`${colors.magenta}${colors.bright}🕸️  DATABASE CONNECTION${colors.reset}`);
            console.log('─'.repeat(40));
            console.log('\x1b[36m[ DATABASE ]\x1b[0m', '\x1b[32mConnected to MongoDB ✅\x1b[0m');
        } catch (err) {
            console.warn("\x1b[33m[ WARNING ]\x1b[0m Could not connect to MongoDB. Continuing without database functionality.");
            console.error(err.message);
        }
    }
}

const localDb = require('./utils/localDb.js');
const db = useMongo && client ? client.db("PrimeMusicSSRR") : null;
const playlistCollection = db ? db.collection("SongPlayLists") : localDb("SongPlayLists");
const autoplayCollection = db ? db.collection("AutoplaySettings") : localDb("AutoplaySettings");
const languageCollection = db ? db.collection("GuildLanguages") : localDb("GuildLanguages");

function getLanguageCollection() {
    return languageCollection;
}

module.exports = {
    connectToDatabase,
    playlistCollection,
    autoplayCollection,
    getLanguageCollection,
};
