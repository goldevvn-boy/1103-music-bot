// Prefix commands: whitelist management (owner) + every slash command via prefix/aliases.
const wl = require('../utils/whitelist.js');
const { getPrefix } = require('../utils/prefix.js');
const PrefixInteraction = require('../utils/prefixInteraction.js');

// Whitelist aliases (owner only)
const WL_ADD = ['whitelist', 'wl', 'wladd', 'allow', 'permit'];
const WL_REMOVE = ['unwhitelist', 'unwl', 'wlremove', 'wlrem', 'disallow', 'deny', 'revoke'];
const WL_LIST = ['wllist', 'wls', 'whitelisted', 'whitelistlist', 'allowed'];

// Aliases for every command: alias -> command name
const ALIASES = {
    play: ['p'], skip: ['s', 'next', 'n'], stop: ['st'], pause: ['ps'], resume: ['r', 'unpause'],
    volume: ['vol', 'v'], shuffle: ['shuf', 'mix'], clear: ['cq', 'clearqueue'], seek: [],
    jump: ['skipto', 'jt'], move: ['mv'], remove: ['rm', 'rem'], autoplay: ['ap'],
    filters: ['filter', 'fx'], search: ['find', 'sr'], trackinfo: ['ti', 'info'], voteskip: ['vs'],
    queue: ['q'], np: ['nowplaying', 'current', 'now'],
    join: ['j', 'connect', 'summon', 'come'], leave: ['l', 'dc', 'disconnect', 'lv', 'fuckoff'],
    '247': ['24/7', 'stay', '24h'], history: ['hist'], language: ['lang'],
    help: ['h', 'cmds', 'commands'], ping: ['latency'], stats: ['botinfo'], invite: ['inv'], support: [],
    createplaylist: ['cpl', 'mkpl'], deleteplaylist: ['dpl'], addsong: ['as'], deletesong: ['ds'],
    myplaylists: ['mypl', 'pls'], allplaylists: ['allpl'], playcustomplaylist: ['ppl', 'playpl'],
    savequeue: ['sq'], showsongs: ['ss'],
    setprefix: ['prefix'], setname: ['botname'], setprofile: ['setavatar', 'setpfp'], setbanner: []
};
const ALIAS_MAP = {};
for (const [name, list] of Object.entries(ALIASES)) {
    ALIAS_MAP[name] = name;
    for (const a of list) ALIAS_MAP[a] = name;
}

function parseUserId(arg, message) {
    const mention = message.mentions.users.first();
    if (mention) return mention.id;
    const m = /^<@!?(\d{15,25})>$|^(\d{15,25})$/.exec(arg || '');
    return m ? (m[1] || m[2]) : null;
}

async function handleWhitelist(message, cmd, args, prefix) {
    let action = null;
    if (WL_LIST.includes(cmd)) action = 'list';
    else if (WL_REMOVE.includes(cmd)) action = 'remove';
    else if (WL_ADD.includes(cmd)) {
        const sub = (args[0] || '').toLowerCase();
        if (['add', 'remove', 'rm', 'list'].includes(sub)) {
            args.shift();
            action = sub === 'rm' ? 'remove' : sub;
        } else if (cmd === 'whitelist' && !args.length) action = 'list';
        else action = 'add';
    }
    if (!action) return false;

    if (action === 'list') {
        const users = wl.list();
        await message.reply(users.length
            ? `✅ **Whitelisted users (${users.length}):**\n${users.map(id => `• <@${id}> (\`${id}\`)`).join('\n')}`
            : 'The whitelist is empty.');
        return true;
    }

    const id = parseUserId(args[0], message);
    if (!id) { await message.reply(`❌ Usage: \`${prefix}${cmd} @user\` or \`${prefix}${cmd} <user id>\``); return true; }

    if (action === 'add') {
        const r = wl.add(id);
        await message.reply(r.ok ? `✅ Whitelisted <@${id}>.` : (r.reason === 'owner' ? '👑 That user is the owner already.' : 'ℹ️ That user is already whitelisted.'));
    } else {
        const r = wl.remove(id);
        await message.reply(r.ok ? `✅ Removed <@${id}> from the whitelist.` : 'ℹ️ That user isn\'t whitelisted.');
    }
    return true;
}

module.exports = async (client, message) => {
    try {
        if (message.author.bot || !message.guild) return;
        const prefix = getPrefix(message.guild.id);
        // Works with the prefix (default "!") or by mentioning the bot: "@bot play song"
        let used = null;
        if (message.content.startsWith(prefix)) used = prefix;
        else {
            const m = new RegExp(`^<@!?${client.user.id}>\\s*`).exec(message.content);
            if (m) used = m[0];
        }
        if (!used) return;

        // Only the owner and whitelisted users can use the bot; others are ignored.
        if (!wl.hasAccess(message.author.id)) return;

        const args = message.content.slice(used.length).trim().split(/\s+/);
        const cmd = (args.shift() || '').toLowerCase();
        if (!cmd) return;

        if (wl.isOwner(message.author.id) && await handleWhitelist(message, cmd, args, prefix)) return;

        // Owner diagnostic: shows node status and which search sources work.
        if (wl.isOwner(message.author.id) && ['lltest', 'nodetest', 'lavalink', 'll'].includes(cmd)) {
            const { getLavalinkManager } = require('../lavalink.js');
            const { diagnose } = require('../utils/resolver.js');
            const mgr = getLavalinkManager();
            const st = mgr?.getNodeStatus?.();
            const nodes = (st?.nodes || []).map(n => `${n.online ? '✅' : '❌'} ${n.name} (${n.host}:${n.port})${n.lastError ? ' — ' + n.lastError : ''}`).join('\n') || 'No nodes configured';
            let report;
            try { report = await diagnose(client, args.join(' ') || undefined); } catch (e) { report = `Error: ${e.message}`; }
            return message.reply(`**Lavalink nodes**\n${nodes}\n\n**Search sources**\n${report}`.slice(0, 1900));
        }

        const name = ALIAS_MAP[cmd] || cmd;
        const command = client.commands.get(name);
        if (!command || name === 'whitelist') return;

        if (!message.member) await message.guild.members.fetch(message.author.id).catch(() => {});

        const interaction = new PrefixInteraction(client, message, command, args);
        if (interaction.parseError) {
            return message.reply(`❌ ${interaction.parseError.replace('Usage: ', `Usage: \`${prefix}${name} `) + (interaction.parseError.startsWith('Usage:') ? '`' : '')}`).catch(() => {});
        }

        await command.run(client, interaction);
    } catch (error) {
        console.error('[ PREFIX ] Error running prefix command:', error);
        message.reply('❌ Something went wrong running that command.').catch(() => {});
    }
};
