# 🎵 1103 Music Bot

Lavalink-powered Discord music bot (discord.js + Riffy), rebranded as **1103 Music**.

## Setup
1. `npm install`
2. Copy `.env.example` to `.env` and set `DISCORD_TOKEN` (and `MONGODB_URI` for playlists/autoplay/language).
3. `npm start`

Lavalink is preconfigured: `lavalinkv4.serenetia.com:443` (secure, v4 — see `.env.example`).

## Hosting
- **Node.js 20 LTS** (22 also works; minimum 18)
- Startup command: `npm start` (runs `node index.js`), after `npm install`
- Required env: `DISCORD_TOKEN` only (the application ID is read from the token automatically)
- Database: built-in local JSON store (`data/db`) by default — no MongoDB needed. Set a real `MONGODB_URI` to use MongoDB instead. Keep the `data/` folder when updating the bot so settings/playlists aren't lost.

## Access control
- **Owner:** `1242869508981391504` — the only one who can manage the whitelist.
- Only the owner and whitelisted users can use the bot's commands.
- Whitelist is stored in `data/whitelist.json`.

### Slash commands (owner only)
`/whitelist add <user>` · `/whitelist remove <user>` · `/whitelist list`

### Prefix commands with aliases (owner only, default prefix `!`)
| Action | Aliases |
|---|---|
| Add | `!whitelist add @u`, `!wl @u`, `!wladd`, `!allow`, `!permit` |
| Remove | `!unwhitelist`, `!unwl`, `!wlremove`, `!wlrem`, `!disallow`, `!deny`, `!revoke` (or `!wl remove @u`) |
| List | `!wllist`, `!wls`, `!whitelisted`, `!allowed` (or `!wl list`) |

Users can be a mention or a raw user ID.

### Prefix commands for everything
Every slash command also works with the prefix (default `!`, change with `/setprefix`) or by mentioning the bot, e.g. `!play never gonna give you up`, `@bot skip`.
Aliases: `p` play · `s`/`next` skip · `st` stop · `ps` pause · `r` resume · `vol`/`v` volume · `q` queue · `np` now playing · `j`/`join` join · `l`/`leave`/`dc` leave · `247`/`stay` 24/7 · `ap` autoplay · `shuf` shuffle · `h` help.

### Troubleshooting
Owner command `!lltest` (aliases `!ll`, `!lavalink`, `!nodetest`) shows node status and which search sources (YouTube, YT Music, SoundCloud, ...) the Lavalink node can actually search.

### Owner profile commands (owner only)
`/setprofile <image>` · `/setbanner <image>` · `/setname <name>` · `/setprefix <prefix|reset>` (per server, used by the `!wl` style commands)

License: MIT (see LICENSE).
