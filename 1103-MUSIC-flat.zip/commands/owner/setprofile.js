const { SlashCommandBuilder, MessageFlags } = require('discord.js');
const { requireOwner } = require('../../utils/ownerOnly.js');

const data = new SlashCommandBuilder()
  .setName('setprofile')
  .setDescription('Owner only: change the bot profile picture')
  .addAttachmentOption(o => o.setName('image').setDescription('PNG / JPG / GIF image').setRequired(true));

module.exports = {
  data,
  permissions: '0',
  run: async (client, interaction) => {
    if (!(await requireOwner(interaction))) return;
    await interaction.deferReply({ flags: MessageFlags.Ephemeral });
    const file = interaction.options.getAttachment('image');
    if (!file.contentType?.startsWith('image/')) {
      return interaction.editReply('❌ Please upload an image file.');
    }
    try {
      await client.user.setAvatar(file.url);
      return interaction.editReply('✅ Bot profile picture updated.');
    } catch (e) {
      return interaction.editReply(`❌ Failed: ${e.message}\n(Discord limits how often the avatar can be changed — try again later.)`);
    }
  }
};
