const { SlashCommandBuilder, MessageFlags, Routes } = require('discord.js');
const { requireOwner } = require('../../utils/ownerOnly.js');

const data = new SlashCommandBuilder()
  .setName('setbanner')
  .setDescription('Owner only: change the bot banner')
  .addAttachmentOption(o => o.setName('image').setDescription('PNG / JPG / GIF image').setRequired(true));

module.exports = {
  data,
  permissions: '0',
  run: async (client, interaction) => {
    if (!(await requireOwner(interaction))) return;
    await interaction.deferReply({ flags: MessageFlags.Ephemeral });
    const file = interaction.options.getAttachment('image');
    if (!file.contentType?.startsWith('image/')) {
      return interaction.editReply('❌ Please upload an image file.');
    }
    try {
      if (typeof client.user.setBanner === 'function') {
        await client.user.setBanner(file.url);
      } else {
        const buf = Buffer.from(await (await fetch(file.url)).arrayBuffer());
        const uri = `data:${file.contentType};base64,${buf.toString('base64')}`;
        await client.rest.patch(Routes.user('@me'), { body: { banner: uri } });
      }
      return interaction.editReply('✅ Bot banner updated.');
    } catch (e) {
      return interaction.editReply(`❌ Failed: ${e.message}`);
    }
  }
};
