const { SlashCommandBuilder, MessageFlags } = require('discord.js');
const { requireOwner } = require('../../utils/ownerOnly.js');

const data = new SlashCommandBuilder()
  .setName('setname')
  .setDescription('Owner only: change the bot username')
  .addStringOption(o => o.setName('name').setDescription('New bot name').setRequired(true).setMinLength(2).setMaxLength(32));

module.exports = {
  data,
  permissions: '0',
  run: async (client, interaction) => {
    if (!(await requireOwner(interaction))) return;
    await interaction.deferReply({ flags: MessageFlags.Ephemeral });
    try {
      await client.user.setUsername(interaction.options.getString('name'));
      return interaction.editReply('✅ Bot name updated.');
    } catch (e) {
      return interaction.editReply(`❌ Failed: ${e.message}\n(Discord limits username changes to about twice per hour.)`);
    }
  }
};
