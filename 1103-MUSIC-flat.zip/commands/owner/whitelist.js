const { SlashCommandBuilder, MessageFlags } = require('discord.js');
const wl = require('../../utils/whitelist.js');

const data = new SlashCommandBuilder()
  .setName('whitelist')
  .setDescription('Owner only: manage who can use the bot')
  .addSubcommand(s => s.setName('add').setDescription('Whitelist a user')
    .addUserOption(o => o.setName('user').setDescription('User to whitelist').setRequired(true)))
  .addSubcommand(s => s.setName('remove').setDescription('Remove a user from the whitelist')
    .addUserOption(o => o.setName('user').setDescription('User to remove').setRequired(true)))
  .addSubcommand(s => s.setName('list').setDescription('Show whitelisted users'));

module.exports = {
  data,
  permissions: '0',
  run: async (client, interaction) => {
    const reply = (content) => interaction.reply({ content, flags: MessageFlags.Ephemeral });

    if (!wl.isOwner(interaction.user.id)) {
      return reply('❌ Only the bot owner can use this command.');
    }

    const sub = interaction.options.getSubcommand();

    if (sub === 'list') {
      const users = wl.list();
      return reply(users.length
        ? `✅ **Whitelisted users (${users.length}):**\n${users.map(id => `• <@${id}> (\`${id}\`)`).join('\n')}`
        : 'The whitelist is empty.');
    }

    const user = interaction.options.getUser('user');
    if (user.bot) return reply('❌ You can\'t whitelist a bot.');

    if (sub === 'add') {
      const r = wl.add(user.id);
      if (r.ok) return reply(`✅ Whitelisted <@${user.id}>.`);
      return reply(r.reason === 'owner' ? '👑 That user is the owner already.' : 'ℹ️ That user is already whitelisted.');
    }

    const r = wl.remove(user.id);
    return reply(r.ok ? `✅ Removed <@${user.id}> from the whitelist.` : 'ℹ️ That user isn\'t whitelisted.');
  }
};
