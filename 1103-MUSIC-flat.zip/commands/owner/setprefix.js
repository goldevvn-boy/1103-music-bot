const { SlashCommandBuilder, MessageFlags } = require('discord.js');
const { requireOwner } = require('../../utils/ownerOnly.js');
const { setPrefix } = require('../../utils/prefix.js');
const config = require('../../config.js');

const data = new SlashCommandBuilder()
  .setName('setprefix')
  .setDescription('Owner only: set a custom prefix for this server')
  .addStringOption(o => o.setName('prefix').setDescription('New prefix (1-5 chars), or "reset" for default').setRequired(true).setMaxLength(5));

module.exports = {
  data,
  permissions: '0',
  run: async (client, interaction) => {
    if (!(await requireOwner(interaction))) return;
    const input = interaction.options.getString('prefix').trim();
    if (!input || /\s/.test(input)) {
      return interaction.reply({ content: '❌ The prefix can\'t be empty or contain spaces.', flags: MessageFlags.Ephemeral });
    }
    if (input.toLowerCase() === 'reset') {
      setPrefix(interaction.guildId, null);
      return interaction.reply({ content: `✅ Prefix reset to \`${config.prefix}\`.`, flags: MessageFlags.Ephemeral });
    }
    setPrefix(interaction.guildId, input);
    return interaction.reply({ content: `✅ Prefix for this server is now \`${input}\`.`, flags: MessageFlags.Ephemeral });
  }
};
