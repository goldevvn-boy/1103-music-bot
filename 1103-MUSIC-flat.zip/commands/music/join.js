const { later } = require('../../utils/autoDelete.js');
const { SlashCommandBuilder } = require('discord.js');
const { sendErrorResponse, sendSuccessResponse, handleCommandError, safeDeferReply } = require('../../utils/responseHandler.js');
const { checkVoiceChannel } = require('../../utils/voiceChannelCheck.js');
const { getLavalinkManager } = require('../../lavalink.js');

const data = new SlashCommandBuilder()
  .setName('join')
  .setDescription('Make the bot join your voice channel');

async function waitConnected(player, timeoutMs = 7000) {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
        if (player?.connected) return true;
        await new Promise(r => setTimeout(r, 150));
    }
    return false;
}

module.exports = {
    data,
    run: async (client, interaction) => {
        try {
            const deferred = await safeDeferReply(interaction);
            if (!deferred && !interaction.deferred && !interaction.replied) return;

            const existing = client.riffy.players.get(interaction.guildId);
            const check = await checkVoiceChannel(interaction, existing);
            if (!check.allowed) {
                const reply = await interaction.editReply(check.response);
                later(() => reply?.delete?.().catch(() => {}), 5000);
                return reply;
            }

            const channelId = interaction.member.voice.channelId;
            if (existing && existing.voiceChannel === channelId && existing.connected) {
                return sendErrorResponse(interaction, '## Already Connected\n\nI\'m already in your voice channel.');
            }

            const nodeManager = getLavalinkManager();
            try {
                await nodeManager?.ensureNodeAvailable();
            } catch {
                return sendErrorResponse(interaction, '## No Lavalink Node\n\nNo Lavalink node is connected right now.\nPlease try again in a moment.');
            }

            const player = client.riffy.createConnection({
                guildId: interaction.guildId,
                voiceChannel: channelId,
                textChannel: interaction.channelId,
                deaf: true
            });

            if (!(await waitConnected(player))) {
                throw new Error('Voice connection was not established.');
            }

            const name = interaction.member.voice.channel?.name || 'your voice channel';
            return sendSuccessResponse(interaction, `## Joined\n\nJoined **${name}**.`);
        } catch (error) {
            return handleCommandError(interaction, error, 'join', '## Error\n\nCould not join the voice channel.\nCheck my permissions (Connect / Speak) and try again.');
        }
    }
};
