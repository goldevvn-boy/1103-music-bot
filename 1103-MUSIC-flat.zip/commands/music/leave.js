const { later } = require('../../utils/autoDelete.js');
const { SlashCommandBuilder } = require('discord.js');
const { sendErrorResponse, sendSuccessResponse, handleCommandError, safeDeferReply } = require('../../utils/responseHandler.js');
const { checkVoiceChannel } = require('../../utils/voiceChannelCheck.js');
const { cleanupTrackMessages } = require('../../player.js');

const data = new SlashCommandBuilder()
  .setName('leave')
  .setDescription('Make the bot leave the voice channel');

module.exports = {
    data,
    run: async (client, interaction) => {
        try {
            const deferred = await safeDeferReply(interaction);
            if (!deferred && !interaction.deferred && !interaction.replied) return;

            const player = client.riffy.players.get(interaction.guildId);
            if (!player) {
                return sendErrorResponse(interaction, '## Not Connected\n\nI\'m not in a voice channel.');
            }

            const check = await checkVoiceChannel(interaction, player);
            if (!check.allowed) {
                const reply = await interaction.editReply(check.response);
                later(() => reply?.delete?.().catch(() => {}), 5000);
                return reply;
            }

            await cleanupTrackMessages(client, player).catch(() => {});
            try { player.queue.clear(); } catch {}
            try { player.stop(); } catch {}
            player.destroy();

            return sendSuccessResponse(interaction, '## Left\n\nDisconnected from the voice channel.');
        } catch (error) {
            return handleCommandError(interaction, error, 'leave', '## Error\n\nCould not leave the voice channel.');
        }
    }
};
