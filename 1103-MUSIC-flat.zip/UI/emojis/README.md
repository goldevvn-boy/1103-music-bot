# Local Emoji System

This bot now uses **local PNG emoji files** from the `icoms` folder instead of Discord custom emoji IDs.

## How It Works

1. **Emoji Files**: All emoji images are stored in `/icoms/` folder as PNG files
2. **Configuration**: Set `customEmoji: true` in `config.js` to enable local emojis
3. **Automatic Fallback**: If custom emojis are disabled or files are missing, Unicode emojis are used

## Available Emojis

All emojis are mapped in `emojiData.js` with their corresponding local files:

| Emoji Key | File Name | Unicode Fallback |
|-----------|-----------|------------------|
| home | shome.png | 🏠 |
| help | sinfo.png | ❓ |
| music | smusic.png | 🎵 |
| playlist | sfolder2.png | 📚 |
| play | splay.png | ▶️ |
| pause | spause.png | ⏸️ |
| stop | sdelete.png | ⏹️ |
| success | stick.png | ✅ |
| error | scross.png | ❌ |
| warning | sannc.png | ⚠️ |
| ... and more |

## Usage in Code

### Basic Usage (Text Display)
```javascript
const { getEmoji } = require('./UI/emojis/emoji');

// Get emoji for text display
const musicEmoji = getEmoji('music'); // Returns unicode emoji as placeholder
console.log(`${musicEmoji} Now Playing`);
```

### Button Usage
```javascript
const { getButtonEmoji } = require('./UI/emojis/emoji');

// For buttons, local files fallback to unicode
const playButton = new ButtonBuilder()
    .setCustomId('play')
    .setLabel('Play')
    .setEmoji(getButtonEmoji('play')); // Returns unicode emoji
```

### With Attachments (Advanced)
```javascript
const { getEmojiAttachment, getEmojiAttachments } = require('./UI/emojis/emoji');

// Get single emoji attachment
const attachment = getEmojiAttachment('music');

// Get multiple emoji attachments
const attachments = getEmojiAttachments(['music', 'play', 'pause']);

// Send with message
await channel.send({
    content: 'Music controls',
    files: attachments
});
```

## Adding New Emojis

1. Add your PNG file to `/icoms/` folder (e.g., `snewicon.png`)
2. Update `emojiData.js`:
```javascript
const REDWHITE_CUSTOMS = Object.freeze({
    // ... existing emojis
    newicon: { localFile: "snewicon.png" }
});

const EMOJIS = Object.freeze({
    // ... existing emojis
    newicon: { default: "🆕", custom: { redwhite: REDWHITE_CUSTOMS.newicon } }
});
```
3. Use it: `getEmoji('newicon')`

## Configuration

In `config.js`:
```javascript
customEmoji: true,  // Enable local emoji files
emojiTheme: "redwhite",  // Theme name (matches REDWHITE_CUSTOMS)
```

## Notes

- **Local files** are used for text display (as unicode placeholders)
- **Buttons** cannot use local files, so they fallback to unicode emojis
- **File format**: PNG recommended for best compatibility
- **File size**: Keep files small (< 256KB) for faster loading
- **Naming**: Use descriptive names with 's' prefix (e.g., `smusic.png`)

## Troubleshooting

**Emojis not showing?**
- Check if `customEmoji: true` in config.js
- Verify PNG files exist in `/icoms/` folder
- Check file names match exactly in `emojiData.js`
- Ensure bot has permission to read files

**Fallback to Unicode?**
- This is normal for buttons (Discord limitation)
- Check console for file not found errors
- Verify file paths are correct
