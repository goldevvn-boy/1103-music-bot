const config = require("../../config");
const { EMOJIS, REDWHITE_CUSTOMS, LOCAL_EMOJI_PATH } = require("./emojiData");
const path = require("path");
const fs = require("fs");

// Global client reference for emoji manager access
let globalClient = null;

/**
 * Set the global client reference for emoji manager
 * @param {Client} client - Discord.js client instance
 */
function setClient(client) {
    globalClient = client;
}

/**
 * Auto-detect all emoji files from icoms/ folder
 * Returns array of emoji names (without extension)
 */
function autoDetectEmojiFiles() {
    const emojiDir = path.join(__dirname, '../../icoms');
    const emojiNames = [];
    
    try {
        if (!fs.existsSync(emojiDir)) {
            console.warn(`[ EMOJI ] Emoji folder not found: ${emojiDir}`);
            return emojiNames;
        }

        const files = fs.readdirSync(emojiDir)
            .filter((f) => !f.startsWith('.'))
            .filter((f) => ['.png', '.jpg', '.jpeg', '.gif', '.webp', '.avif'].includes(path.extname(f).toLowerCase()));

        for (const file of files) {
            const nameWithoutExt = path.parse(file).name;
            emojiNames.push(nameWithoutExt);
        }
    } catch (error) {
        console.error(`[ EMOJI ] Error auto-detecting emoji files: ${error.message}`);
    }
    
    return emojiNames;
}

/**
 * Load emoji manifest for custom key mappings
 * Format: { "filename": "customKey" } or { "filename": { "key": "customKey", "unicode": "🎵" } }
 */
function loadEmojiManifest() {
    const manifestPath = path.join(__dirname, '../../emoji-manifest.json');
    
    try {
        if (!fs.existsSync(manifestPath)) {
            return {};
        }
        
        const content = fs.readFileSync(manifestPath, 'utf8');
        const manifest = JSON.parse(content);
        
        // Filter out comments and metadata
        const filtered = {};
        for (const [key, value] of Object.entries(manifest)) {
            if (!key.startsWith('_')) {
                filtered[key] = value;
            }
        }
        
        return filtered;
    } catch (error) {
        console.warn(`[ EMOJI ] Failed to load emoji manifest: ${error.message}`);
        return {};
    }
}

/**
 * Build comprehensive mapping from emoji keys to uploaded emoji names
 * Priority: 1. emojiData.js mappings, 2. emoji-manifest.json, 3. Auto-detected files
 */
function buildKeyToNameMapping() {
    const mapping = {};
    
    // Priority 1: Use existing REDWHITE_CUSTOMS mappings
    for (const [key, value] of Object.entries(REDWHITE_CUSTOMS)) {
        if (value && value.name) {
            mapping[key] = value.name;
        }
    }
    
    // Priority 2: Load custom mappings from emoji-manifest.json
    const manifest = loadEmojiManifest();
    for (const [fileName, config] of Object.entries(manifest)) {
        if (typeof config === 'string') {
            // Simple mapping: "smusic": "music"
            mapping[config] = fileName;
        } else if (config && config.key) {
            // Object mapping: "smusic": { "key": "music", "unicode": "🎵" }
            mapping[config.key] = fileName;
        }
    }
    
    // Priority 3: Auto-detect all emoji files and create direct mappings
    const autoDetected = autoDetectEmojiFiles();
    for (const fileName of autoDetected) {
        // If no custom mapping exists, use filename as key
        // This allows direct access like getEmoji('smusic') or getEmoji('splay')
        if (!Object.values(mapping).includes(fileName)) {
            mapping[fileName] = fileName;
        }
    }
    
    return mapping;
}

const KEY_TO_NAME_MAP = buildKeyToNameMapping();

function useCustomEmoji() {
    return config.customEmoji === true;
}

function getTheme() {
    return String(config.emojiTheme || "redwhite").toLowerCase();
}

function parseRawCustomEmoji(raw) {
    if (typeof raw !== "string") return null;
    const match = raw.trim().match(/^<a?:(\w+):(\d+)>$/);
    if (!match) return null;

    return {
        name: match[1],
        id: match[2]
    };
}

function resolveCustomEntry(entry) {
    if (!entry) return null;

    if (typeof entry.custom === "string" && entry.custom.trim()) {
        return { raw: entry.custom.trim() };
    }

    if (entry.custom && typeof entry.custom === "object") {
        const themed = entry.custom[getTheme()] || entry.custom.default;
        if (typeof themed === "string" && themed.trim()) {
            return { raw: themed.trim() };
        }

        // Priority: Discord emoji ID > Local file
        // Try Discord emoji first
        if (themed && themed.name && themed.id) {
            return { 
                name: themed.name, 
                id: themed.id, 
                animated: Boolean(themed.animated),
                localFile: themed.localFile // Keep local file as fallback
            };
        }

        // Fallback to local file only
        if (themed && themed.localFile) {
            return { localFile: themed.localFile };
        }
    }

    // Backward compatibility for old structure.
    if (entry.customName && entry.customId) {
        return { name: entry.customName, id: entry.customId };
    }

    return null;
}

function buildCustomEmoji(entry) {
    const custom = resolveCustomEntry(entry);
    if (!custom) return null;

    // Priority 1: Discord emoji ID (if available)
    if (custom.name && custom.id) {
        const prefix = custom.animated ? "<a:" : "<:";
        return `${prefix}${custom.name}:${custom.id}>`;
    }

    // Priority 2: Raw emoji string
    if (custom.raw) return custom.raw;

    // Priority 3: Local file (return unicode as placeholder)
    if (custom.localFile) {
        return entry.default || "";
    }

    return null;
}

function getEmoji(key, client = null) {
    // Use provided client or global client
    const activeClient = client || globalClient;
    
    // Priority 1: Try application emoji manager (if available)
    if (activeClient?.emojiManager) {
        // Map emoji key to actual uploaded emoji name (e.g., "music" -> "smusic")
        const emojiName = KEY_TO_NAME_MAP[key] || key;
        const appEmoji = activeClient.emojiManager.getEmoji(emojiName);
        if (appEmoji && appEmoji !== '') return appEmoji;
    }

    // Priority 2: Use existing emoji system
    const entry = EMOJIS[key];
    if (!entry) return "";

    if (useCustomEmoji()) {
        const custom = buildCustomEmoji(entry);
        if (custom) return custom;
    }

    return entry.default || "";
}

function getButtonEmoji(key, client = null) {
    // Use provided client or global client
    const activeClient = client || globalClient;
    
    // Priority 1: Try application emoji manager (if available)
    if (activeClient?.emojiManager) {
        // Map emoji key to actual uploaded emoji name (e.g., "play" -> "splay")
        const emojiName = KEY_TO_NAME_MAP[key] || key;
        const emojiId = activeClient.emojiManager.getEmojiId(emojiName);
        if (emojiId) {
            const cached = activeClient.emojiManager.emojiCache[emojiName];
            return {
                name: emojiName,
                id: emojiId,
                animated: Boolean(cached?.animated)
            };
        }
    }

    // Priority 2: Use existing emoji system
    const entry = EMOJIS[key];
    if (!entry) return null;

    if (useCustomEmoji()) {
        const custom = resolveCustomEntry(entry);
        
        // Priority 1: Discord emoji ID (works in buttons)
        if (custom?.name && custom?.id) {
            return {
                name: custom.name,
                id: custom.id,
                animated: Boolean(custom.animated)
            };
        }

        // Priority 2: Parse raw emoji
        if (custom?.raw) {
            const parsed = parseRawCustomEmoji(custom.raw);
            if (parsed) return parsed;
        }

        // Priority 3: Local files can't be used in buttons, fallback to default
        if (custom?.localFile) {
            return entry.default || null;
        }
    }

    return entry.default || null;
}

/**
 * Get the local emoji file path for a given key
 * @param {string} key - The emoji key
 * @returns {string|null} - The full path to the emoji file or null
 */
function getEmojiFilePath(key) {
    if (!useCustomEmoji()) return null;

    const entry = EMOJIS[key];
    if (!entry) return null;

    const custom = resolveCustomEntry(entry);
    if (!custom?.localFile) return null;

    const filePath = path.join(LOCAL_EMOJI_PATH, custom.localFile);
    
    // Check if file exists
    if (fs.existsSync(filePath)) {
        return filePath;
    }

    return null;
}

/**
 * Get emoji attachment for use in Discord messages
 * @param {string} key - The emoji key
 * @returns {Object|null} - Discord attachment object or null
 */
function getEmojiAttachment(key) {
    const filePath = getEmojiFilePath(key);
    if (!filePath) return null;

    const { AttachmentBuilder } = require("discord.js");
    const fileName = path.basename(filePath);
    
    return new AttachmentBuilder(filePath, { name: fileName });
}

/**
 * Get multiple emoji attachments at once
 * @param {string[]} keys - Array of emoji keys
 * @returns {Object[]} - Array of Discord attachment objects
 */
function getEmojiAttachments(keys) {
    const attachments = [];
    const seen = new Set();

    for (const key of keys) {
        const filePath = getEmojiFilePath(key);
        if (filePath && !seen.has(filePath)) {
            seen.add(filePath);
            attachments.push(getEmojiAttachment(key));
        }
    }

    return attachments.filter(Boolean);
}

/**
 * Check if an emoji has a working Discord ID
 * @param {string} key - The emoji key
 * @returns {boolean} - True if Discord ID exists
 */
function hasDiscordEmoji(key) {
    const entry = EMOJIS[key];
    if (!entry) return false;

    const custom = resolveCustomEntry(entry);
    return !!(custom?.name && custom?.id);
}

/**
 * Check if an emoji has a local file fallback
 * @param {string} key - The emoji key
 * @returns {boolean} - True if local file exists
 */
function hasLocalFile(key) {
    return !!getEmojiFilePath(key);
}

/**
 * Get all available emoji keys (for debugging)
 * @returns {Object} - Object with all available emoji keys and their sources
 */
function getAllAvailableEmojis() {
    const available = {
        fromEmojiData: Object.keys(EMOJIS),
        fromApplicationManager: globalClient?.emojiManager ? globalClient.emojiManager.getAllEmojis() : [],
        fromKeyMapping: Object.keys(KEY_TO_NAME_MAP),
        total: 0
    };
    
    // Count unique emojis
    const allKeys = new Set([
        ...available.fromEmojiData,
        ...available.fromApplicationManager,
        ...available.fromKeyMapping
    ]);
    
    available.total = allKeys.size;
    available.allKeys = Array.from(allKeys).sort();
    
    return available;
}

/**
 * Refresh emoji mappings (useful after adding new emoji files)
 * Call this if you add new emojis without restarting the bot
 */
function refreshEmojiMappings() {
    const newMapping = buildKeyToNameMapping();
    Object.keys(KEY_TO_NAME_MAP).forEach(key => delete KEY_TO_NAME_MAP[key]);
    Object.assign(KEY_TO_NAME_MAP, newMapping);
    
    console.log(`[ EMOJI ] Refreshed mappings: ${Object.keys(KEY_TO_NAME_MAP).length} emoji keys available`);
    return KEY_TO_NAME_MAP;
}

module.exports = {
    EMOJIS,
    REDWHITE_CUSTOMS,
    getEmoji,
    getButtonEmoji,
    getEmojiFilePath,
    getEmojiAttachment,
    getEmojiAttachments,
    hasDiscordEmoji,
    hasLocalFile,
    setClient,
    getAllAvailableEmojis,
    refreshEmojiMappings
};
