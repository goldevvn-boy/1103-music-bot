// Wraps a prefix message so existing slash-command handlers can run unchanged.
const { MessageFlags } = require('discord.js');

const EPHEMERAL = MessageFlags.Ephemeral;

function clean(payload) {
    const p = typeof payload === 'string' ? { content: payload } : { ...payload };
    delete p.fetchReply;
    delete p.ephemeral;
    if (p.flags !== undefined) {
        let f = typeof p.flags === 'object' && p.flags.bitfield !== undefined ? p.flags.bitfield : Number(p.flags);
        f = f & ~EPHEMERAL;
        if (f) p.flags = f; else delete p.flags;
    }
    p.allowedMentions = { parse: [] };
    return p;
}

function buildOptions(command, args, message) {
    const json = command.data.toJSON();
    let opts = json.options || [];
    let subcommand = null;
    const values = {};

    if (opts.some(o => o.type === 1)) {
        const name = (args.shift() || '').toLowerCase();
        const sub = opts.find(o => o.type === 1 && o.name === name);
        if (!sub) return { error: `Usage: ${opts.filter(o => o.type === 1).map(o => o.name).join(' | ')}` };
        subcommand = sub.name;
        opts = sub.options || [];
    }

    const rest = [...args];
    opts.forEach((o, i) => {
        const isLast = i === opts.length - 1;
        if (o.type === 11) { // attachment
            const a = message.attachments.first();
            if (a) values[o.name] = a;
            return;
        }
        if (!rest.length) return;
        if (o.type === 3) values[o.name] = isLast ? rest.splice(0).join(' ') : rest.shift();
        else if (o.type === 4 || o.type === 10) {
            const n = o.type === 4 ? parseInt(rest[0], 10) : parseFloat(rest[0]);
            if (!Number.isNaN(n)) { values[o.name] = n; rest.shift(); }
        } else if (o.type === 5) {
            const v = rest.shift().toLowerCase();
            values[o.name] = ['true', 'on', 'yes', 'enable', 'enabled', '1'].includes(v);
        } else if (o.type === 6) {
            const m = /^<@!?(\d{15,25})>$|^(\d{15,25})$/.exec(rest[0] || '');
            if (m) { values[o.name] = m[1] || m[2]; rest.shift(); }
        }
    });

    const missing = opts.filter(o => o.required && values[o.name] === undefined);
    if (missing.length) {
        const usage = opts.map(o => (o.required ? `<${o.name}>` : `[${o.name}]`)).join(' ');
        return { error: `Usage: ${usage}`, usage };
    }
    return { values, subcommand };
}

class PrefixInteraction {
    constructor(client, message, command, args) {
        this.client = client;
        this.message = message;
        this.commandName = command.data.name;
        this.id = message.id;
        this.guild = message.guild;
        this.guildId = message.guild.id;
        this.channel = message.channel;
        this.channelId = message.channel.id;
        this.member = message.member;
        this.user = message.author;
        this.createdTimestamp = message.createdTimestamp;
        this.deferred = false;
        this.replied = false;
        this._msg = null;

        const parsed = buildOptions(command, args, message);
        this.parseError = parsed.error || null;
        const values = parsed.values || {};
        this.options = {
            getSubcommand: () => parsed.subcommand,
            getString: (n) => (values[n] !== undefined ? String(values[n]) : null),
            getInteger: (n) => (values[n] !== undefined ? values[n] : null),
            getNumber: (n) => (values[n] !== undefined ? values[n] : null),
            getBoolean: (n) => (values[n] !== undefined ? values[n] : null),
            getAttachment: (n) => values[n] || null,
            getUser: (n) => (values[n] ? (message.mentions.users.get(values[n]) || client.users.cache.get(values[n]) || { id: values[n], bot: false }) : null),
            getFocused: () => ''
        };
    }

    isChatInputCommand() { return true; }
    isButton() { return false; }
    isStringSelectMenu() { return false; }
    isRepliable() { return true; }

    async deferReply() {
        this.deferred = true;
        await this.channel.sendTyping().catch(() => {});
    }
    async _send(payload) {
        this._msg = await this.channel.send(clean(payload));
        return this._msg;
    }
    async reply(payload) {
        this.replied = true;
        return this._send(payload);
    }
    async editReply(payload) {
        this.replied = true;
        if (this._msg) {
            try { return (this._msg = await this._msg.edit(clean(payload))); } catch {}
        }
        return this._send(payload);
    }
    async followUp(payload) {
        this.replied = true;
        return this.channel.send(clean(payload));
    }
    async deleteReply() { await this._msg?.delete().catch(() => {}); }
    async deferUpdate() {}
    async update(payload) { return this.editReply(payload); }
}

module.exports = PrefixInteraction;
