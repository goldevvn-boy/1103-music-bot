const fs = require('fs');
const path = require('path');
const config = require('../config.js');

const FILE = path.join(__dirname, '..', 'data', 'prefixes.json');

function load() {
    try { return JSON.parse(fs.readFileSync(FILE, 'utf8')); } catch { return {}; }
}

function getPrefix(guildId) {
    return load()[guildId] || config.prefix;
}

function setPrefix(guildId, prefix) {
    const all = load();
    if (!prefix) delete all[guildId]; else all[guildId] = prefix;
    fs.mkdirSync(path.dirname(FILE), { recursive: true });
    fs.writeFileSync(FILE, JSON.stringify(all, null, 2));
}

module.exports = { getPrefix, setPrefix };
