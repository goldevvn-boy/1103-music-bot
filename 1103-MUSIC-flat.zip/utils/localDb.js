// Tiny MongoDB-compatible JSON store so the bot works without MongoDB.
// Supports the subset the bot uses: find/findOne/insertOne/updateOne/deleteOne,
// equality filters, $set, $push ($each/$slice), $addToSet, $pull, upsert.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DIR = path.join(__dirname, '..', 'data', 'db');

const clone = (v) => (v === undefined ? v : JSON.parse(JSON.stringify(v)));
const deepEqual = (a, b) => JSON.stringify(a) === JSON.stringify(b);

function matches(doc, filter = {}) {
    return Object.entries(filter).every(([k, v]) => deepEqual(doc[k], v));
}

// For $pull: remove items that equal the value, or contain all the given fields.
function pullMatches(item, cond) {
    if (cond && typeof cond === 'object' && !Array.isArray(cond) && item && typeof item === 'object') {
        return Object.entries(cond).every(([k, v]) => deepEqual(item[k], v));
    }
    return deepEqual(item, cond);
}

class Collection {
    constructor(name) {
        this.file = path.join(DIR, `${name}.json`);
        this.docs = [];
        this.timer = null;
        try { this.docs = JSON.parse(fs.readFileSync(this.file, 'utf8')); } catch { this.docs = []; }
    }

    _save() {
        clearTimeout(this.timer);
        this.timer = setTimeout(() => {
            try {
                fs.mkdirSync(DIR, { recursive: true });
                const tmp = this.file + '.tmp';
                fs.writeFileSync(tmp, JSON.stringify(this.docs));
                fs.renameSync(tmp, this.file);
            } catch (e) {
                console.error('[ LOCAL DB ] Failed to save:', e.message);
            }
        }, 150);
    }

    find(filter = {}) {
        const result = this.docs.filter(d => matches(d, filter)).map(clone);
        return { toArray: async () => result };
    }

    async findOne(filter = {}) {
        return clone(this.docs.find(d => matches(d, filter))) || null;
    }

    async insertOne(doc) {
        const copy = clone(doc);
        if (!copy._id) copy._id = crypto.randomBytes(12).toString('hex');
        this.docs.push(copy);
        this._save();
        return { acknowledged: true, insertedId: copy._id };
    }

    async deleteOne(filter = {}) {
        const i = this.docs.findIndex(d => matches(d, filter));
        if (i === -1) return { acknowledged: true, deletedCount: 0 };
        this.docs.splice(i, 1);
        this._save();
        return { acknowledged: true, deletedCount: 1 };
    }

    async updateOne(filter = {}, update = {}, options = {}) {
        let doc = this.docs.find(d => matches(d, filter));
        let upserted = false;
        if (!doc) {
            if (!options.upsert) return { acknowledged: true, matchedCount: 0, modifiedCount: 0 };
            doc = { _id: crypto.randomBytes(12).toString('hex') };
            for (const [k, v] of Object.entries(filter)) doc[k] = clone(v);
            this.docs.push(doc);
            upserted = true;
        }

        for (const [k, v] of Object.entries(update.$set || {})) doc[k] = clone(v);

        for (const [k, v] of Object.entries(update.$push || {})) {
            if (!Array.isArray(doc[k])) doc[k] = [];
            if (v && typeof v === 'object' && Array.isArray(v.$each)) {
                doc[k].push(...clone(v.$each));
                if (typeof v.$slice === 'number') {
                    doc[k] = v.$slice < 0 ? doc[k].slice(v.$slice) : doc[k].slice(0, v.$slice);
                }
            } else {
                doc[k].push(clone(v));
            }
        }

        for (const [k, v] of Object.entries(update.$addToSet || {})) {
            if (!Array.isArray(doc[k])) doc[k] = [];
            if (!doc[k].some(x => deepEqual(x, v))) doc[k].push(clone(v));
        }

        for (const [k, v] of Object.entries(update.$pull || {})) {
            if (Array.isArray(doc[k])) doc[k] = doc[k].filter(x => !pullMatches(x, v));
        }

        this._save();
        return { acknowledged: true, matchedCount: upserted ? 0 : 1, modifiedCount: 1, upsertedCount: upserted ? 1 : 0 };
    }
}

const cache = {};
module.exports = (name) => (cache[name] ||= new Collection(name));
