const config = require('../config.js');

// Timed auto-deletion of the bot's own notices. OFF by default (set AUTO_DELETE=true to enable).
function later(fn, ms) {
    if (!config.autoDelete) return null;
    return setTimeout(fn, ms);
}

module.exports = { later };
