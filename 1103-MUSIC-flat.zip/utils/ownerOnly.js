const { MessageFlags } = require('discord.js');
const wl = require('./whitelist.js');

// Returns true if allowed; otherwise replies and returns false.
async function requireOwner(interaction) {
    if (wl.isOwner(interaction.user.id)) return true;
    await interaction.reply({ content: '❌ Only the bot owner can use this command.', flags: MessageFlags.Ephemeral });
    return false;
}

module.exports = { requireOwner };
