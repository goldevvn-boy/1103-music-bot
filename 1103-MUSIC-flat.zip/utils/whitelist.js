const fs = require('fs');
const path = require('path');
const config = require('../config.js');

const FILE = path.join(__dirname, '..', 'data', 'whitelist.json');

function load() {
    try {
        const raw = JSON.parse(fs.readFileSync(FILE, 'utf8'));
        return Array.isArray(raw.users) ? raw.users : [];
    } catch {
        return [];
    }
}

function save(users) {
    fs.mkdirSync(path.dirname(FILE), { recursive: true });
    fs.writeFileSync(FILE, JSON.stringify({ users }, null, 2));
}

const isOwner = (id) => config.ownerID.includes(String(id));
const isWhitelisted = (id) => load().includes(String(id));
// Owner is always allowed; everyone else needs to be whitelisted.
const hasAccess = (id) => isOwner(id) || isWhitelisted(id);
const list = () => load();

function add(id) {
    id = String(id);
    if (isOwner(id)) return { ok: false, reason: 'owner' };
    const users = load();
    if (users.includes(id)) return { ok: false, reason: 'exists' };
    users.push(id);
    save(users);
    return { ok: true };
}

function remove(id) {
    id = String(id);
    const users = load();
    if (!users.includes(id)) return { ok: false, reason: 'missing' };
    save(users.filter(u => u !== id));
    return { ok: true };
}

module.exports = { isOwner, isWhitelisted, hasAccess, list, add, remove };
