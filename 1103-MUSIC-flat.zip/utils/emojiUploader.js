const fs = require('fs');
const path = require('path');
const { REST } = require('@discordjs/rest');
const { Routes } = require('discord-api-types/v10');
const config = require('../config');
const colors = require('../UI/colors/colors');

/**
 * Emoji Uploader - Automatically uploads local PNG emojis to Discord Application
 * This allows the bot to use custom emojis without needing a server
 */

class EmojiUploader {
    constructor(client) {
        this.client = client;
        this.rest = new REST({ version: '10' }).setToken(config.TOKEN || process.env.TOKEN);
        this.iconsPath = path.join(__dirname, '../icoms');
        this.uploadedEmojis = new Map();
    }

    /**
     * Get all PNG files from icoms folder
     */
    getLocalEmojiFiles() {
        try {
            const files = fs.readdirSync(this.iconsPath);
            return files.filter(file => file.endsWith('.png'));
        } catch (error) {
            console.error(`${colors.red}Error reading icoms folder:${colors.reset}`, error.message);
            return [];
        }
    }

    /**
     * Convert PNG file to base64 data URI
     */
    fileToDataUri(filePath) {
        try {
            const fileBuffer = fs.readFileSync(filePath);
            const base64 = fileBuffer.toString('base64');
            return `data:image/png;base64,${base64}`;
        } catch (error) {
            console.error(`${colors.red}Error reading file ${filePath}:${colors.reset}`, error.message);
            return null;
        }
    }

    /**
     * Get emoji name from filename (remove 's' prefix and .png extension)
     */
    getEmojiName(filename) {
        // Remove .png extension
        let name = filename.replace('.png', '');
        
        // Remove 's' prefix if exists (smusic -> music)
        if (name.startsWith('s') && name.length > 1) {
            name = name.substring(1);
        }
        
        // Add prefix to make it unique
        return `x_${name}`;
    }

    /**
     * Fetch existing application emojis
     */
    async fetchExistingEmojis() {
        try {
            const emojis = await this.rest.get(
                Routes.applicationEmojis(this.client.user.id)
            );
            
            console.log(`${colors.cyan}[ EMOJI ]${colors.reset} ${colors.green}Found ${emojis.items.length} existing application emojis${colors.reset}`);
            
            // Store existing emojis
            for (const emoji of emojis.items) {
                this.uploadedEmojis.set(emoji.name, emoji);
            }
            
            return emojis.items;
        } catch (error) {
            console.error(`${colors.red}Error fetching existing emojis:${colors.reset}`, error.message);
            return [];
        }
    }

    /**
     * Upload a single emoji to Discord Application
     */
    async uploadEmoji(filename) {
        const filePath = path.join(this.iconsPath, filename);
        const emojiName = this.getEmojiName(filename);
        
        // Check if emoji already exists
        if (this.uploadedEmojis.has(emojiName)) {
            console.log(`${colors.yellow}[ EMOJI ]${colors.reset} ${colors.gray}Skipping ${emojiName} (already exists)${colors.reset}`);
            return this.uploadedEmojis.get(emojiName);
        }

        try {
            const imageData = this.fileToDataUri(filePath);
            if (!imageData) {
                throw new Error('Failed to read image file');
            }

            const emoji = await this.rest.post(
                Routes.applicationEmojis(this.client.user.id),
                {
                    body: {
                        name: emojiName,
                        image: imageData
                    }
                }
            );

            this.uploadedEmojis.set(emojiName, emoji);
            console.log(`${colors.cyan}[ EMOJI ]${colors.reset} ${colors.green}✓ Uploaded: ${emojiName} (${filename})${colors.reset}`);
            
            return emoji;
        } catch (error) {
            if (error.code === 30008) {
                console.error(`${colors.red}[ EMOJI ]${colors.reset} ${colors.yellow}Maximum emojis reached (50 limit)${colors.reset}`);
            } else if (error.code === 50035) {
                console.error(`${colors.red}[ EMOJI ]${colors.reset} ${colors.yellow}Invalid image format for ${filename}${colors.reset}`);
            } else {
                console.error(`${colors.red}[ EMOJI ]${colors.reset} ${colors.red}Failed to upload ${emojiName}:${colors.reset}`, error.message);
            }
            return null;
        }
    }

    /**
     * Upload all emojis from icoms folder
     */
    async uploadAllEmojis() {
        console.log('\n' + '═'.repeat(60));
        console.log(`${colors.cyan}${colors.bright}🎨 EMOJI UPLOADER${colors.reset}`);
        console.log('═'.repeat(60) + '\n');

        // Fetch existing emojis first
        await this.fetchExistingEmojis();

        const files = this.getLocalEmojiFiles();
        console.log(`${colors.cyan}[ EMOJI ]${colors.reset} Found ${files.length} PNG files in icoms folder\n`);

        if (files.length === 0) {
            console.log(`${colors.yellow}[ EMOJI ]${colors.reset} No PNG files found in icoms folder`);
            return;
        }

        let uploaded = 0;
        let skipped = 0;
        let failed = 0;

        for (const file of files) {
            const result = await this.uploadEmoji(file);
            
            if (result) {
                if (this.uploadedEmojis.has(this.getEmojiName(file))) {
                    if (result.id) {
                        uploaded++;
                    } else {
                        skipped++;
                    }
                }
            } else {
                failed++;
            }

            // Rate limit: wait 1 second between uploads
            await new Promise(resolve => setTimeout(resolve, 1000));
        }

        console.log('\n' + '═'.repeat(60));
        console.log(`${colors.green}✅ Upload Complete!${colors.reset}`);
        console.log('═'.repeat(60));
        console.log(`${colors.cyan}[ SUMMARY ]${colors.reset}`);
        console.log(`  Uploaded: ${colors.green}${uploaded}${colors.reset}`);
        console.log(`  Skipped:  ${colors.yellow}${skipped}${colors.reset}`);
        console.log(`  Failed:   ${colors.red}${failed}${colors.reset}`);
        console.log(`  Total:    ${colors.cyan}${files.length}${colors.reset}`);
        console.log('═'.repeat(60) + '\n');

        return this.uploadedEmojis;
    }

    /**
     * Generate emojiData.js with uploaded emoji IDs
     */
    async generateEmojiData() {
        if (this.uploadedEmojis.size === 0) {
            console.log(`${colors.yellow}[ EMOJI ]${colors.reset} No emojis to generate data for`);
            return;
        }

        const emojiDataPath = path.join(__dirname, '../UI/emojis/emojiData.js');
        
        // Create emoji mapping
        const emojiMap = {};
        for (const [name, emoji] of this.uploadedEmojis.entries()) {
            // Remove x_ prefix for key
            const key = name.replace('x_', '');
            emojiMap[key] = {
                name: emoji.name,
                id: emoji.id
            };
        }

        // Generate file content
        const fileContent = `// Auto-generated emoji data from uploaded application emojis
// Generated: ${new Date().toISOString()}
const path = require('path');

const LOCAL_EMOJI_PATH = path.join(__dirname, '../../icoms');

// Application emoji IDs (uploaded to Discord Developer Portal)
const REDWHITE_CUSTOMS = Object.freeze(${JSON.stringify(emojiMap, null, 4)});

// Emoji definitions with Unicode fallbacks
const EMOJIS = Object.freeze({
    home: { default: "🏠", custom: { redwhite: REDWHITE_CUSTOMS.home } },
    help: { default: "❓", custom: { redwhite: REDWHITE_CUSTOMS.info } },
    music: { default: "🎵", custom: { redwhite: REDWHITE_CUSTOMS.music } },
    playlist: { default: "📚", custom: { redwhite: REDWHITE_CUSTOMS.folder2 } },
    basic: { default: "⚙️", custom: { redwhite: REDWHITE_CUSTOMS.setting } },
    utility: { default: "🧰", custom: { redwhite: REDWHITE_CUSTOMS.tools } },
    commands: { default: "🧩", custom: { redwhite: REDWHITE_CUSTOMS.js } },
    servers: { default: "🌐", custom: { redwhite: REDWHITE_CUSTOMS.world } },
    users: { default: "👥", custom: { redwhite: REDWHITE_CUSTOMS.members } },
    uptime: { default: "⏱️", custom: { redwhite: REDWHITE_CUSTOMS.time } },
    ping: { default: "📶", custom: { redwhite: REDWHITE_CUSTOMS.ping } },
    info: { default: "ℹ️", custom: { redwhite: REDWHITE_CUSTOMS.info } },
    support: { default: "🛟", custom: { redwhite: REDWHITE_CUSTOMS.partner } },
    github: { default: "💻", custom: { redwhite: REDWHITE_CUSTOMS.github } },
    play: { default: "▶️", custom: { redwhite: REDWHITE_CUSTOMS.play } },
    pause: { default: "⏸️", custom: { redwhite: REDWHITE_CUSTOMS.pause } },
    stop: { default: "⏹️", custom: { redwhite: REDWHITE_CUSTOMS.delete } },
    next: { default: "⏭️", custom: { redwhite: REDWHITE_CUSTOMS.right } },
    back: { default: "⏮️", custom: { redwhite: REDWHITE_CUSTOMS.left } },
    settings: { default: "⚙️", custom: { redwhite: REDWHITE_CUSTOMS.setting } },
    tools: { default: "🛠️", custom: { redwhite: REDWHITE_CUSTOMS.tools } },
    success: { default: "✅", custom: { redwhite: REDWHITE_CUSTOMS.tick } },
    error: { default: "❌", custom: { redwhite: REDWHITE_CUSTOMS.cross } },
    warning: { default: "⚠️", custom: { redwhite: REDWHITE_CUSTOMS.annc } },
    queue: { default: "📋", custom: { redwhite: REDWHITE_CUSTOMS.homes } },
    search: { default: "🔎", custom: { redwhite: REDWHITE_CUSTOMS.replit } },
    volume: { default: "🔊", custom: { redwhite: REDWHITE_CUSTOMS.speak } },
    voice: { default: "🔈", custom: { redwhite: REDWHITE_CUSTOMS.mic } },
    ticket: { default: "🎫", custom: { redwhite: REDWHITE_CUSTOMS.mail } },
    link: { default: "🔗", custom: { redwhite: REDWHITE_CUSTOMS.github } },
    mod: { default: "🛡️", custom: { redwhite: REDWHITE_CUSTOMS.mod } },
    security: { default: "🔒", custom: { redwhite: REDWHITE_CUSTOMS.automod } },
    welcome: { default: "👋", custom: { redwhite: REDWHITE_CUSTOMS.heart } },
    owner: { default: "👑", custom: { redwhite: REDWHITE_CUSTOMS.owner } },
    shuffle: { default: "🔀", custom: { redwhite: REDWHITE_CUSTOMS.world } },
    folder: { default: "📁", custom: { redwhite: REDWHITE_CUSTOMS.folder1 } },
    cloud: { default: "☁️", custom: { redwhite: REDWHITE_CUSTOMS.cloud } }
});

module.exports = {
    EMOJIS,
    REDWHITE_CUSTOMS,
    LOCAL_EMOJI_PATH
};
`;

        try {
            fs.writeFileSync(emojiDataPath, fileContent, 'utf8');
            console.log(`${colors.cyan}[ EMOJI ]${colors.reset} ${colors.green}✓ Generated emojiData.js with ${this.uploadedEmojis.size} emojis${colors.reset}`);
        } catch (error) {
            console.error(`${colors.red}[ EMOJI ]${colors.reset} Failed to write emojiData.js:`, error.message);
        }
    }

    /**
     * Delete all application emojis (cleanup)
     */
    async deleteAllEmojis() {
        console.log(`${colors.yellow}[ EMOJI ]${colors.reset} Deleting all application emojis...`);
        
        const existing = await this.fetchExistingEmojis();
        let deleted = 0;

        for (const emoji of existing) {
            try {
                await this.rest.delete(
                    Routes.applicationEmoji(this.client.user.id, emoji.id)
                );
                console.log(`${colors.cyan}[ EMOJI ]${colors.reset} ${colors.red}✗ Deleted: ${emoji.name}${colors.reset}`);
                deleted++;
                
                // Rate limit
                await new Promise(resolve => setTimeout(resolve, 500));
            } catch (error) {
                console.error(`${colors.red}[ EMOJI ]${colors.reset} Failed to delete ${emoji.name}:`, error.message);
            }
        }

        console.log(`${colors.cyan}[ EMOJI ]${colors.reset} ${colors.green}Deleted ${deleted} emojis${colors.reset}`);
    }
}

module.exports = { EmojiUploader };
