// Resolve a query with fallback across search sources, so playback still works
// when one source (e.g. YouTube) is blocked or empty on the Lavalink node.
const SOURCES = ['ytsearch', 'ytmsearch', 'scsearch', 'spsearch', 'dzsearch'];
const isUrl = (q) => /^https?:\/\//i.test(String(q).trim());
const usable = (res) => res && Array.isArray(res.tracks) && res.tracks.length > 0
    && ['search', 'track', 'playlist'].includes(res.loadType);

const errText = (res) => res?.exception?.message || res?.data?.message || res?.data?.cause || null;
const isNodeDown = (e) => {
    const msg = e?.message || '';
    return msg.includes('fetch failed') || msg.includes('No nodes are available') || e?.cause?.code === 'ECONNREFUSED';
};

async function resolveQuery(client, query, requester) {
    query = String(query).trim();
    if (isUrl(query)) {
        const res = await client.riffy.resolve({ query, requester });
        if (!usable(res)) console.warn(`[ RESOLVE ] url -> loadType=${res?.loadType} ${errText(res) || ''}`);
        return res;
    }

    let lastRes = null;
    let lastErr = null;
    for (const source of SOURCES) {
        try {
            const res = await client.riffy.resolve({ query, source, requester });
            if (usable(res)) return res;
            console.warn(`[ RESOLVE ] ${source} -> loadType=${res?.loadType} tracks=${res?.tracks?.length ?? 0} ${errText(res) || ''}`);
            lastRes = res || lastRes;
        } catch (e) {
            lastErr = e;
            console.warn(`[ RESOLVE ] ${source} -> error: ${e?.message}`);
            if (isNodeDown(e)) throw e;
        }
    }
    if (lastRes) return lastRes;
    throw lastErr || new Error('No results');
}

// Used by the owner command "!lltest" to see which sources the node can search.
async function diagnose(client, query = 'never gonna give you up') {
    const out = [];
    for (const source of SOURCES) {
        try {
            const res = await client.riffy.resolve({ query, source, requester: 'diag' });
            out.push(`${usable(res) ? '✅' : '❌'} \`${source}\` → ${res?.loadType} (${res?.tracks?.length ?? 0} tracks)${errText(res) ? ` — ${String(errText(res)).slice(0, 150)}` : ''}`);
        } catch (e) {
            out.push(`❌ \`${source}\` → ${String(e?.message || e).slice(0, 150)}`);
        }
    }
    return out.join('\n');
}

module.exports = { resolveQuery, diagnose };
