

require('dotenv').config();

module.exports = {
  TOKEN: process.env.DISCORD_TOKEN || "",
  language: process.env.LANGUAGE || "en",
  // Only this user is the owner: full access + can manage the whitelist.
  ownerID: ["1242869508981391504"],
  prefix: process.env.PREFIX || "!",
  mongodbUri: process.env.MONGODB_URI || "",
  spotifyClientId: process.env.SPOTIFY_CLIENT_ID || "",
  spotifyClientSecret: process.env.SPOTIFY_CLIENT_SECRET || "",
  setupFilePath: './commands/setup.json',
  commandsDir: './commands',
  port: process.env.PORT || 3000,
  embedColor: process.env.EMBED_COLOR || "#e11d2e",
  customEmoji: process.env.CUSTOM_EMOJI !== "false",
  emojiTheme: process.env.EMOJI_THEME || "redwhite",
  helpBannerUrl: process.env.HELP_BANNER_URL || "",
  activityName: process.env.ACTIVITY_NAME || "YouTube Music | 1103 Music",
  activityType: process.env.ACTIVITY_TYPE || "PLAYING",
  SupportServer: process.env.SUPPORT_SERVER || "https://discord.gg/UbCBkkrk",
  autoDelete: process.env.AUTO_DELETE === "true",
  embedTimeout: parseInt(process.env.EMBED_TIMEOUT) || 5,
  showProgressBar: process.env.SHOW_PROGRESS_BAR !== "false",
  showVisualizer: process.env.SHOW_VISUALIZER !== "false",
  generateSongCard: process.env.GENERATE_SONG_CARD !== "false",
  metadataTag: process.env.METADATA_TAG !== "false",
  lowMemoryMode: process.env.LOW_MEMORY_MODE === "true",
  errorLog: process.env.ERROR_LOG || "",
  
  applicationEmojis: {
    enabled: process.env.APP_EMOJIS_ENABLED !== "false",
    autoSync: process.env.APP_EMOJIS_AUTO_SYNC !== "false",
    deleteMissing: process.env.APP_EMOJIS_DELETE_MISSING === "true",
    emojiDir: process.env.EMOJI_DIR || './icoms',
  },
  
  nodes: [
    {
      name: process.env.LAVALINK_NODE1_NAME || "1103 Lavalink",
      password: process.env.LAVALINK_PASSWORD || "https://dsc.gg/ajidevserver",
      host: process.env.LAVALINK_HOST || "lavalinkv4.serenetia.com",
      port: parseInt(process.env.LAVALINK_PORT) || 443,
      secure: process.env.LAVALINK_SECURE ? process.env.LAVALINK_SECURE === "true" : true
    },
    // Optional backup node: set LAVALINK2_HOST (+ PORT / PASSWORD / SECURE) in .env
    ...(process.env.LAVALINK2_HOST ? [{
      name: "1103 Lavalink 2",
      password: process.env.LAVALINK2_PASSWORD || "youshallnotpass",
      host: process.env.LAVALINK2_HOST,
      port: parseInt(process.env.LAVALINK2_PORT) || 443,
      secure: process.env.LAVALINK2_SECURE !== "false"
    }] : [])
  ]
}
